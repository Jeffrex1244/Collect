package com.archive.studio;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
  private final Handler ui = new Handler(Looper.getMainLooper());
  private WebView web;
  private TextView status;
  private static final String BASE_URL="http://127.0.0.1:8876/";
  private ValueCallback<Uri[]> uploadCallback;
  private static final int FILE_PICKER=8001;
  private int dp(int n){return (int)(getResources().getDisplayMetrics().density*n+.5);}
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    LinearLayout frame = new LinearLayout(this);
    frame.setOrientation(LinearLayout.VERTICAL);
    frame.setBackgroundColor(0xff111016);
    status = new TextView(this);
    status.setTextColor(0xffffffff);
    status.setTextSize(14);
    status.setPadding(dp(16),dp(14),dp(16),dp(12));
    status.setText("Starting the built-in V1.5 download engine...");
    frame.addView(status);
    web = new WebView(this);
    web.setBackgroundColor(0xff101014);
    frame.addView(web,new LinearLayout.LayoutParams(-1,0,1f));
    setContentView(frame);
    WebSettings st=web.getSettings();
    st.setJavaScriptEnabled(true);
    st.setDomStorageEnabled(true);
    st.setAllowFileAccess(false);
    st.setAllowContentAccess(false);
    st.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> value,FileChooserParams params) {
        uploadCallback = value;
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/plain");
        try {startActivityForResult(i,FILE_PICKER);return true;}
        catch (Exception e) {uploadCallback=null;return false;}
      }
    });
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView w, WebResourceRequest r){
        Uri uri=r.getUrl();
        if("http".equals(uri.getScheme()) && "127.0.0.1".equals(uri.getHost()))return false;
        try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception ignored){}
        return true;
      }
    });
    web.setDownloadListener((url,userAgent,disposition,mimeType,length)->saveDownload(url,disposition,mimeType));
    new Thread(()->{
      try {
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        InputStream in=getAssets().open("index.html");
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        byte[] buf=new byte[16384]; int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);in.close();
        java.io.File dl=getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if(dl==null)dl=getFilesDir();
        Python.getInstance().getModule("android_entry").callAttr("start",getFilesDir().getAbsolutePath(),new java.io.File(dl,"Instagram Archive").getAbsolutePath(),out.toString("UTF-8"));
        ui.post(()->{status.setVisibility(android.view.View.GONE);web.loadUrl(BASE_URL);});
      }catch(Exception e){ui.post(()->{status.setText("Engine could not start: "+e.getMessage());});}
    },"archive-v15-engine").start();
  }
  private void saveDownload(String url, String disposition, String mime) {
    // Browser does not have filesystem write access; use Android MediaStore to
    // save into visible Downloads without broad ALL_FILES_ACCESS permission.
    new Thread(()->{
      try {
        Uri u=Uri.parse(url);
        if(!"127.0.0.1".equals(u.getHost())||u.getPort()!=8876)throw new SecurityException("Non-local download refused");
        HttpURLConnection conn=(HttpURLConnection)new URL(url).openConnection();
        conn.setConnectTimeout(5000);conn.setReadTimeout(120000);
        if(conn.getResponseCode()!=200)throw new java.io.IOException("HTTP "+conn.getResponseCode());
        String filename=java.net.URLDecoder.decode(u.getLastPathSegment(),"UTF-8");
        if (filename==null||filename.length()==0)filename="instagram-archive.zip";
        filename=filename.replaceAll("[^A-Za-z0-9._-]","_");
        if ("archive.zip".equals(filename))filename="instagram-archive.zip";
        ContentValues v=new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME,filename);
        v.put(MediaStore.Downloads.MIME_TYPE,mime==null?"application/octet-stream":mime);
        v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Instagram Archive");
        Uri saved=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
        if(saved==null)throw new java.io.IOException("Could not reserve Download file");
        try(InputStream src=conn.getInputStream();OutputStream dst=getContentResolver().openOutputStream(saved)) {
           if(dst==null)throw new java.io.IOException("Could not open download destination");
           byte[] buf=new byte[262144];int n;while((n=src.read(buf))!=-1)dst.write(buf,0,n);
        }catch(Exception e){getContentResolver().delete(saved,null,null);throw e;}
        ui.post(()->Toast.makeText(this,"Saved to Downloads/Instagram Archive",Toast.LENGTH_LONG).show());
      }catch(Exception e){ui.post(()->Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}
    },"archive-file-export").start();
  }
  @Override protected void onActivityResult(int request,int result,Intent data){
    super.onActivityResult(request,result,data);
    if(request==FILE_PICKER&&uploadCallback!=null){
      Uri[] chosen=result==RESULT_OK&&data!=null&&data.getData()!=null?new Uri[]{data.getData()}:null;
      uploadCallback.onReceiveValue(chosen);
      uploadCallback=null;
    }
  }
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
