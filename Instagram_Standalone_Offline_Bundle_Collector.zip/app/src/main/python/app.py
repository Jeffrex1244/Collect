#!/usr/bin/env python3
"""Instagram Archive Studio — a local-only media archiver powered by Instaloader.
No cloud backend, telemetry, or remote web UI. Requests only to Instagram through Instaloader.
"""
from __future__ import annotations

import argparse
import io
import queue
import importlib.util
import json
import mimetypes
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
import traceback
import webbrowser
import zipfile
from collections import deque
from importlib import metadata as package_metadata
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

APP_VERSION = "1.5-android"
REQUIRED_GALLERY_VERSION = "1.32.18"


def installed_gallery_version():
    try:
        return package_metadata.version("gallery-dl")
    except package_metadata.PackageNotFoundError:
        return "not installed"


BASE = Path(os.environ.get("IAS_BASE", str(Path(__file__).resolve().parent)))
DATA = BASE / "local_data"
SESSIONS = DATA / "sessions"
WEB = BASE / "web"
DEFAULT_OUT = Path(os.environ.get("IAS_DOWNLOAD_DIR", str(Path.home() / "Downloads" / "Instagram Archive")))
SESSION = SESSIONS / "instagram.session"
ACCOUNT = SESSIONS / "account.json"
BROWSER = SESSIONS / "browser.json"
IMPORTED_COOKIES = SESSIONS / "imported-instagram-cookies.txt"
USER_RE = re.compile(r"^[A-Za-z0-9._]{1,30}$")
SAFE_FILES = {".jpg", ".jpeg", ".png", ".webp", ".mp4", ".mov", ".txt", ".json", ".xz"}


def normalize_profile(raw: str) -> str:
    """Accept @username, username or instagram.com/username/ (not post URLs)."""
    raw = (raw or "").strip()
    if raw.startswith("@"):
        raw = raw[1:]
    if raw.lower().startswith(("instagram.com/", "www.instagram.com/")):
        raw = "https://" + raw
    if raw.startswith(("https://", "http://")):
        url = urlparse(raw)
        if (url.hostname or "").lower() not in ("www.instagram.com", "instagram.com"):
            raise ValueError("Please enter an Instagram profile URL, not another website.")
        parts = [x for x in url.path.split("/") if x]
        if len(parts) != 1 or parts[0].lower() in ("p", "reel", "reels", "stories", "explore", "accounts", "direct"):
            raise ValueError("Use a profile link, for example instagram.com/natgeo, not a post link.")
        raw = parts[0]
    if not USER_RE.fullmatch(raw) or raw in (".", ".."):
        raise ValueError("Instagram usernames contain only letters, numbers, periods and underscores.")
    return raw.lower()


def safe_label(s: str, fallback="untitled") -> str:
    """Avoid accidental nested paths and Windows reserved names."""
    s = re.sub(r"[<>:\"/\\|?*\x00-\x1f]", "_", str(s))
    s = re.sub(r"[. ]+$", "", s).strip()
    s = s[:65] or fallback
    if s.upper().split(".")[0] in {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}:
        s = "_" + s
    return s


def files_summary(root: Path, limit=36):
    counts = {"photos": 0, "videos": 0, "other": 0, "bytes": 0}
    media = []
    if not root.is_dir():
        return counts, media
    for path in root.rglob("*"):
        if not path.is_file() or path.is_symlink():
            continue
        ext = path.suffix.lower()
        if ext == ".jpg" or ext in (".jpeg", ".png", ".webp"):
            bucket = "photos"
        elif ext in (".mp4", ".mov"):
            bucket = "videos"
        else:
            bucket = "other"
        counts[bucket] += 1
        try:
            size = path.stat().st_size
        except OSError:
            size = 0
        counts["bytes"] += size
        if bucket != "other":
            media.append((path.stat().st_mtime, path.relative_to(root).as_posix(), bucket))
    media.sort(reverse=True)
    return counts, [{"file": filename, "kind": kind} for _, filename, kind in media[:limit]]


def make_archive(root: Path, target_zip: Path, stop=None):
    """Save a ZIP outside the profile's media folder; exclude temp/symlinks."""
    if not root.is_dir():
        raise FileNotFoundError("No downloaded folder yet.")
    items = [p for p in root.rglob("*") if p.is_file() and not p.is_symlink()]
    if not items:
        raise ValueError("No files to archive yet.")
    target_zip.parent.mkdir(parents=True, exist_ok=True)
    tmp = target_zip.with_suffix(".partial")
    try:
        with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as z:
            for path in items:
                if stop is not None and stop.is_set():
                    raise InterruptedError("Archive cancelled")
                z.write(path, arcname=(root.name + "/" + path.relative_to(root).as_posix()))
        tmp.replace(target_zip)
    finally:
        if tmp.exists():
            tmp.unlink()
    return target_zip


def load_browser() -> str | None:
    try:
        value = json.loads(BROWSER.read_text("utf-8")).get("browser", "")
        return value if value in ("firefox", "chrome", "edge", "brave") else None
    except (OSError, json.JSONDecodeError, ValueError):
        return None


def parse_instagram_cookie_export(contents: str) -> str:
    """Accept Netscape cookies.txt exports; retain *only* Instagram cookies.

    The data comes from an explicit local file selection, never from an
    Internet request. The exported cookies are highly sensitive.
    """
    if not isinstance(contents, str) or len(contents.encode("utf-8")) > 200_000:
        raise ValueError("Choose an Instagram cookies.txt export smaller than 200 KB.")
    kept = []
    session = False
    for line in contents.splitlines():
        stripped = line.strip()
        if not stripped or (stripped.startswith("#") and not stripped.startswith("#HttpOnly_")):
            continue
        fields = line.split("\t", 6)
        if len(fields) != 7:
            continue
        domain, include_subdomains, path, secure, expires, name, value = fields
        domain = domain.removeprefix("#HttpOnly_").strip().lower().lstrip(".")
        if domain != "instagram.com" and not domain.endswith(".instagram.com"):
            continue
        if not name or not value or "\r" in value or "\x00" in value:
            continue
        if include_subdomains.upper() not in ("TRUE", "FALSE") or secure.upper() not in ("TRUE", "FALSE"):
            continue
        try:
            expiry = int(expires)
        except ValueError:
            continue
        if expiry and expiry < time.time():
            continue
        if name == "sessionid":
            session = True
        kept.append(line)
    if not session:
        raise ValueError("No valid Instagram sessionid found in this cookies.txt file. Export cookies from instagram.com *after* logging in, using Netscape format.")
    return "# Netscape HTTP Cookie File\n# Instagram Archive Studio: local-only Instagram cookies\n" + "\n".join(kept) + "\n"


def import_cookie_export(contents: str):
    data = parse_instagram_cookie_export(contents)
    SESSIONS.mkdir(parents=True, exist_ok=True)
    temp = IMPORTED_COOKIES.with_suffix(".tmp")
    try:
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(data)
        temp.replace(IMPORTED_COOKIES)
        if os.name != "nt":
            IMPORTED_COOKIES.chmod(0o600)
    finally:
        temp.unlink(missing_ok=True)
    BROWSER.unlink(missing_ok=True)
    with STATE.lock:
        STATE.browser = None
        STATE.account = "Imported Instagram session"
        STATE.auth_status = "connected"
        STATE.auth_error = ""
    STATE.log("Imported Instagram-only cookies locally. Cookie values are never printed in the log. This session has not yet been verified with Instagram.")


def browser_cookie_check(browser):
    """Check existing login locally; never transmit or persist browser cookies."""
    from gallery_dl import cookies
    try:
        jar = cookies.load_cookies((browser, None, None, None, ".instagram.com"))
    except PermissionError as exc:
        raise RuntimeError(
            f"{browser.title()} has locked its Cookies database (Windows Permission denied). "
            "Close ALL browser windows and background processes in Task Manager, then reconnect while it stays closed; "
            "or use the Import cookies.txt option, which works while Chrome is running. "
            "Do not run the app as administrator."
        ) from exc
    if not any(c.name == "sessionid" and c.value and "instagram.com" in c.domain for c in jar):
        raise RuntimeError("No usable Instagram session cookie found in this browser. Log in to instagram.com there first, then retry. Firefox is recommended if Chrome or Edge blocks cookie access.")
    return True


def load_username() -> str | None:
    try:
        if not SESSION.is_file():
            return None
        username = json.loads(ACCOUNT.read_text("utf-8")).get("username", "")
        return normalize_profile(username)
    except (OSError, json.JSONDecodeError, ValueError):
        return None


def save_session(loader, username):
    BROWSER.unlink(missing_ok=True)
    IMPORTED_COOKIES.unlink(missing_ok=True)
    SESSIONS.mkdir(parents=True, exist_ok=True)
    loader.save_session_to_file(str(SESSION))
    ACCOUNT.write_text(json.dumps({"username": username}), encoding="utf-8")
    if os.name != "nt":
        try:
            SESSION.chmod(0o600)
            ACCOUNT.chmod(0o600)
        except OSError:
            pass


class Cancelled(Exception):
    pass


class State:
    def __init__(self):
        self.lock = threading.RLock()
        self.cancel = threading.Event()
        self.key = secrets.token_urlsafe(32)
        self.browser = load_browser()
        self.account = (("Browser: " + self.browser.title()) if self.browser else
                        ("Imported Instagram session" if IMPORTED_COOKIES.is_file() else load_username()))
        self.auth_status = "saved" if self.account else "signed_out"
        self.auth_error = ""
        self.twofa_loader = None
        self.twofa_username = None
        self.busy = False
        self.phase = "idle"
        self.profile = None
        self.root = None
        self.output_base = str(DEFAULT_OUT)
        self.item_count = 0
        self.new_count = 0
        self.fail_count = 0
        self.section = ""
        self.section_results = {}
        self.finished_at = None
        self.error = ""
        self.logs = deque(maxlen=200)
        self.zip_file = None
        self.zip_busy = False
        self.started_at = None

    def log(self, line: str):
        line = str(line).replace("\r", " ").replace("\n", " ").strip()
        with self.lock:
            self.logs.append({"time": datetime.now().strftime("%H:%M:%S"), "text": line[:400]})

    def snapshot(self):
        with self.lock:
            root = self.root
            current = {
                "account": self.account,
                "app_version": APP_VERSION,
                "downloader_version": installed_gallery_version(),
                "browser_cookie_available": importlib.util.find_spec("gallery_dl") is not None,
                "browser": self.browser,
                "auth_status": self.auth_status,
                "auth_error": self.auth_error,
                "busy": self.busy,
                "phase": self.phase,
                "profile": self.profile,
                "output_base": self.output_base,
                "root": str(root) if root else "",
                "item_count": self.item_count,
                "new_count": self.new_count,
                "fail_count": self.fail_count,
                "section": self.section,
                "sections": dict(self.section_results),
                "error": self.error,
                "zip_ready": bool(self.zip_file and self.zip_file.is_file()),
                "zip_busy": self.zip_busy,
                "logs": list(self.logs)[-70:],
                "started_at": self.started_at,
                "finished_at": self.finished_at,
            }
        counts, media = files_summary(root) if root else ({"photos":0,"videos":0,"other":0,"bytes":0}, [])
        current["files"] = counts
        current["media"] = media[:24]
        return current


STATE = State()


def get_instaloader(**kwargs):
    try:
        import instaloader
    except ImportError as e:
        raise RuntimeError("Instaloader is not installed. Run start_windows.bat to install dependencies.") from e
    return instaloader.Instaloader(sleep=True, quiet=True, max_connection_attempts=2, request_timeout=30, **kwargs)


def login_worker(username: str, password: str):
    loader = None
    try:
        loader = get_instaloader()
        STATE.log("Signing into Instagram (password is not saved)...")
        try:
            loader.login(username, password)
        except Exception as e:
            if e.__class__.__name__ == "TwoFactorAuthRequiredException":
                with STATE.lock:
                    STATE.twofa_loader = loader
                    STATE.twofa_username = username
                    STATE.auth_status = "two_factor"
                    STATE.auth_error = "Instagram requested 2FA, but the downloader cannot send an SMS or request a fresh code. Only enter a code if Instagram actually provided one. Otherwise, sign into instagram.com normally in Firefox and choose Browser login here."
                STATE.log("Instagram requested two-factor authentication.")
                return
            raise
        save_session(loader, username)
        with STATE.lock:
            STATE.account = username
            STATE.browser = None
            STATE.auth_status = "connected"
            STATE.auth_error = ""
        STATE.log(f"Signed in as @{username}. Session is stored locally.")
    except Exception as e:
        with STATE.lock:
            STATE.auth_status = "error"
            STATE.auth_error = str(e)
        STATE.log(f"Sign-in failed: {e}")
    finally:
        if loader is not STATE.twofa_loader and loader is not None:
            loader.close()


def twofa_worker(code):
    with STATE.lock:
        loader = STATE.twofa_loader
        username = STATE.twofa_username
    try:
        if loader is None:
            raise ValueError("Two-factor login expired. Sign in again.")
        loader.two_factor_login(code)
        save_session(loader, username)
        with STATE.lock:
            STATE.account = username
            STATE.browser = None
            STATE.auth_status = "connected"
            STATE.auth_error = ""
            STATE.twofa_loader = None
            STATE.twofa_username = None
        STATE.log(f"2FA successful, signed in as @{username}.")
    except Exception as e:
        with STATE.lock:
            STATE.auth_status = "two_factor"
            STATE.auth_error = f"Verification failed: {e}"
        STATE.log(f"2FA failed: {e}")
    finally:
        if STATE.twofa_loader is not loader and loader is not None:
            loader.close()


def cookies_worker(browser):
    try:
        if os.environ.get("IAS_ANDROID_EMBEDDED") == "1":
            raise RuntimeError("Android does not allow reading other browsers private cookies. Import an Instagram-only cookies.txt file or use password/2FA login instead.")
        STATE.log(f"Checking existing Instagram cookies in {browser.title()} (on this PC only)...")
        browser_cookie_check(browser)
        SESSIONS.mkdir(parents=True, exist_ok=True)
        BROWSER.write_text(json.dumps({"browser": browser}), encoding="utf-8")
        IMPORTED_COOKIES.unlink(missing_ok=True)
        if os.name != "nt":
            BROWSER.chmod(0o600)
        with STATE.lock:
            pending = STATE.twofa_loader
            STATE.browser = browser
            STATE.account = "Browser: " + browser.title()
            STATE.auth_status = "connected"
            STATE.auth_error = ""
            STATE.twofa_loader = None
            STATE.twofa_username = None
        if pending is not None:
            try: pending.close()
            except Exception: pass
        STATE.log(f"{browser.title()} Instagram login cookie detected locally (not yet verified online). Cookies are read from your browser at download time; none are copied into this app.")
    except Exception as e:
        with STATE.lock:
            STATE.auth_status = "error"
            STATE.auth_error = str(e)
        STATE.log(f"Browser connection failed: {e}")


# gallery-dl keeps its own Instagram endpoint fixes up to date. A child process
# prevents Instagram 429 sleep/retry behavior from freezing the local dashboard.
def check_cancel():
    if STATE.cancel.is_set():
        raise Cancelled("Stopped by user. Existing files have been preserved.")


def section_url(username, section):
    prefix = f"https://www.instagram.com/{username}"
    return {
        "posts": prefix + "/posts/", "reels": prefix + "/reels/",
        "highlights": prefix + "/highlights/",
        "stories": f"https://www.instagram.com/stories/{username}/",
        "picture": prefix + "/avatar/",
    }[section]


def command_for_section(username, section, root, browser=None, legacy_cookies=None, limit=0, metadata=False, captions=False):
    cmd = [sys.executable, "-m", "gallery_dl", "--config-ignore", "--no-input",
           "--retries", "1", "--http-timeout", "15", "--sleep-429", "2",
           "--windows-filenames", "--directory", str(root / ("profile_picture" if section == "picture" else section))]
    # gallery-dl's session cookies can be read directly from a pre-approved browser.
    if browser:
        cmd += ["--cookies-from-browser", browser + "/.instagram.com"]
    elif legacy_cookies:
        cmd += ["--cookies", str(legacy_cookies)]
    if section == "highlights":
        # Subdirectories per highlight, preserving recognizable highlight titles.
        cmd += ["-d", str(root), "-o", 'extractor.instagram.directory=["highlights","{highlight_title}"]']
        # --directory above sets an exact directory; override it by omitting the flag.
        idx = cmd.index("--directory")
        del cmd[idx:idx+2]
    if section in ("posts", "reels") and limit:
        cmd += ["-o", f"extractor.instagram.max-posts={limit}"]
    if metadata or captions:
        cmd.append("--write-metadata")
    cmd += [section_url(username, section)]
    return cmd


def export_legacy_session():
    """Convert old Instaloader session (if any) for gallery-dl compatibility."""
    username = load_username()
    if not username:
        return None
    import http.cookiejar
    loader = get_instaloader()
    try:
        loader.load_session_from_file(username, str(SESSION))
        # Store no additional secrets long-term; temporary legacy Netscape jar only.
        jar = http.cookiejar.MozillaCookieJar()
        for cookie in loader.context._session.cookies:
            jar.set_cookie(cookie)
        path = SESSIONS / "legacy-gallery.cookies.txt"
        jar.filename = str(path)
        jar.save(ignore_discard=True, ignore_expires=True)
        if os.name != 'nt':
            path.chmod(0o600)
        return path
    finally:
        loader.close()


def format_instagram_error(message, *, browser=False, legacy=False):
    """Translate misleading upstream errors; never infer a profile is deleted."""
    lower = message.lower()
    if "notfounderror" in lower or "requested user could not be found" in lower or "missing_required_variable_value" in lower or "keyerror: 'data'" in lower:
        if browser or legacy:
            return ("Instagram profile lookup failed. This does NOT prove the profile does not exist. "
                    "Instagram has recently changed its API and may reject even authenticated requests. "
                    "Verify your existing browser login is still active, then try again. "
                    "If it keeps failing, include the Activity log when reporting it. "
                    "Upstream response: " + message[:250])
        return ("Instagram did not provide profile data for this anonymous request. "
                "A public profile can still require a valid Instagram session for automated downloads. "
                "Connect Instagram using an already signed-in browser and try again. "
                "This does NOT mean the username is wrong. "
                "Upstream response: " + message[:250])
    if "429" in lower or "too many requests" in lower:
        return ("Instagram rate-limited this request (HTTP 429). "
                "Do not repeatedly retry; try later using your normal Instagram browser session. "
                "Upstream response: " + message[:250])
    if "redirect to login" in lower or "401" in lower or "unauthorized" in lower or "redirect to home" in lower:
        return ("Instagram did not accept the download session. "
                "Sign into instagram.com normally in your browser and reconnect it. "
                "Upstream response: " + message[:250])
    return message


def run_gallery(cmd, section, idle_seconds=100):
    """Stream output and enforce an actual interruptible idle timeout."""
    if os.environ.get("IAS_ANDROID_EMBEDDED") == "1":
        return _run_gallery_embedded(cmd, section)
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding="utf-8", errors="replace", bufsize=1)
    q = queue.Queue()
    def collect():
        try:
            for line in proc.stdout:
                q.put(line.rstrip())
        finally:
            q.put(None)
    threading.Thread(target=collect, daemon=True).start()
    last = time.monotonic()
    errors = []
    lines = 0
    try:
        ended = False
        while not ended:
            if STATE.cancel.is_set():
                raise Cancelled("Stopped by user. Existing media are preserved.")
            try:
                line = q.get(timeout=0.25)
            except queue.Empty:
                if time.monotonic() - last > idle_seconds:
                    raise TimeoutError(f"Instagram did not respond for {idle_seconds} seconds in {section}. Stopped waiting; check login or rate limits.")
                if proc.poll() is not None and not q.qsize():
                    # Reader thread might still be flushing, give it a moment.
                    try: line = q.get(timeout=1)
                    except queue.Empty: break
                else:
                    continue
            if line is None:
                ended = True
                break
            last = time.monotonic()
            if line.strip():
                lines += 1
                # Output never contains credentials passed on a command line.
                STATE.log(line[:300])
                if any(x in line.lower() for x in ("[error]", "[warning]", "429 too many", "redirect to login", "403 forbidden", "unauthorized")):
                    errors.append(line[:220])
        code = proc.wait(timeout=3)
        if code:
            raise RuntimeError("; ".join(errors[-2:]) or f"gallery-dl returned exit code {code}. See activity log.")
        if errors:
            raise RuntimeError("; ".join(errors[-2:]))
        return lines
    finally:
        if proc.poll() is None:
            proc.terminate()
            try: proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=3)
        if proc.stdout is not None:
            proc.stdout.close()



def _run_gallery_embedded(cmd, section):
    """Run the installed gallery-dl CLI in-process on Android.

    Chaquopy has no standalone sys.executable to launch with subprocess.
    Existing CLI arguments stay the same. Cancellation is checked between
    media items and after the command. In-flight HTTP waits may continue
    until the configured gallery-dl timeout expires.
    """
    import contextlib
    import logging
    import gallery_dl
    from gallery_dl import job
    from threading import RLock

    class EventLogStream:
        encoding = 'utf-8'
        def __init__(self):
            self.buffer = ''
            self.errors = []
            self.lines = 0
        def write(self, text):
            self.buffer += str(text)
            while '\n' in self.buffer or '\r' in self.buffer:
                positions = [p for p in (self.buffer.find('\n'), self.buffer.find('\r')) if p >= 0]
                i = min(positions)
                line, self.buffer = self.buffer[:i], self.buffer[i+1:]
                line = line.strip()
                if line:
                    self.lines += 1
                    STATE.log(line[:300])
                    if any(term in line.lower() for term in ('[error]', '[warning]', '429 too many', 'redirect to login', '403 forbidden', 'unauthorized')):
                        self.errors.append(line[:220])
            return len(text)
        def flush(self):
            if self.buffer.strip():
                STATE.log(self.buffer.strip()[:300]); self.lines += 1
                self.buffer = ''

    stream = EventLogStream()
    original_argv = sys.argv
    original_job = job.DownloadJob
    # Base DownloadJob may be instantiated once per URL. Checking before
    # each media URL supports stop without a second Python process.
    class CancellableJob(original_job):
        def handle_url(self, *args, **kwargs):
            check_cancel()
            return super().handle_url(*args, **kwargs)
    # Never run two gallery-dl commands concurrently (the UI already enforces this).
    job.DownloadJob = CancellableJob
    sys.argv = ['gallery-dl'] + list(cmd[3:])
    try:
        with contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
            rc = gallery_dl.main()
        stream.flush()
        check_cancel()
        if rc not in (None, 0):
            raise RuntimeError('; '.join(stream.errors[-2:]) or f'gallery-dl returned {rc}')
        if stream.errors:
            raise RuntimeError('; '.join(stream.errors[-2:]))
        return stream.lines
    finally:
        job.DownloadJob = original_job
        sys.argv = original_argv
        stream.flush()

def extract_captions(root, existing_json, keep_json):
    """Create optional caption .txt sidecars from gallery-dl's JSON metadata."""
    done = 0
    for file in root.rglob("*.json"):
        if not file.is_file() or file.is_symlink() or file in existing_json:
            continue
        try:
            obj = json.loads(file.read_text("utf-8"))
            caption = obj.get("description") or obj.get("caption") or ""
            if isinstance(caption, dict):
                caption = caption.get("text", "")
            if isinstance(caption, str) and caption.strip():
                file.with_suffix(".txt").write_text(caption.strip(), encoding="utf-8")
                done += 1
            if not keep_json:
                file.unlink()
        except (OSError, ValueError, TypeError) as e:
            STATE.log(f"Caption extraction warning: {e}")
    return done


def download_worker(opts):
    error_sections = []
    last_failure = ""
    try:
        username = normalize_profile(opts["profile"])
        out_base = Path(os.path.expandvars(os.path.expanduser(opts["folder"]))).resolve()
        out_base.mkdir(parents=True, exist_ok=True)
        root = out_base / username
        root.mkdir(parents=True, exist_ok=True)
        with STATE.lock:
            STATE.profile, STATE.root, STATE.output_base = username, root, str(out_base)
            STATE.zip_file = None
            STATE.section_results = {}
            STATE.item_count = STATE.new_count = STATE.fail_count = 0
            STATE.phase = "connecting"
            STATE.error = ""
            STATE.started_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            STATE.finished_at = None
            STATE.logs.clear()
        version = installed_gallery_version()
        STATE.log(f"Instagram Archive Studio v{APP_VERSION}; gallery-dl {version}. Profile @{username}; folder: {root}")
        if version != REQUIRED_GALLERY_VERSION:
            raise RuntimeError(
                f"gallery-dl {REQUIRED_GALLERY_VERSION} is required, but {version} is installed. "
                "Close this app, then run start_windows.bat (or start_mac_linux.sh) "
                "to upgrade the downloader before trying again."
            )
        browser = load_browser()
        legacy = IMPORTED_COOKIES if not browser and IMPORTED_COOKIES.is_file() else None
        if browser:
            STATE.log(f"Using your existing {browser.title()} login; no new SMS/2FA required.")
        elif legacy:
            STATE.log("Using your imported Instagram cookies.txt session; no browser database access required.")
        else:
            try:
                legacy = export_legacy_session()
                if legacy: STATE.log("Using previously saved username/password session.")
            except Exception as e:
                STATE.log(f"Previously saved Instagram session could not be read: {e}")
        if not browser and not legacy:
            STATE.log("Anonymous public profile mode. Instagram can reject even public profiles with HTTP 429/login redirects.")
        max_count = int(opts.get("limit", 0) or 0)
        for section in ("posts", "reels", "highlights", "stories", "picture"):
            if not opts.get(section):
                continue
            check_cancel()
            if section in ("highlights", "stories") and not (browser or legacy):
                error_sections.append(section)
                with STATE.lock: STATE.section_results[section] = "failed"
                STATE.log(f"Skipped {section}: connect an Instagram browser session first.")
                continue
            with STATE.lock:
                STATE.section, STATE.phase = section, "downloading"
                STATE.section_results[section] = "working"
            STATE.log(f"Fetching {section}... (requests can take 6–12 seconds each)")
            before, _ = files_summary(root)
            existing_json = set(root.rglob("*.json")) if opts.get("captions") else set()
            try:
                cmd = command_for_section(username, section, root, browser, legacy, max_count, opts.get("metadata"), opts.get("captions"))
                run_gallery(cmd, section)
                if opts.get("captions"):
                    saved = extract_captions(root, existing_json, opts.get("metadata"))
                    if saved:
                        STATE.log(f"Saved {saved} caption text files.")
                after, _ = files_summary(root)
                new = max(0, (after["photos"]+after["videos"]) - (before["photos"]+before["videos"]))
                with STATE.lock:
                    STATE.item_count += new
                    STATE.new_count += new
                    STATE.section_results[section] = "done"
                STATE.log(f"{section.title()} done. {new} new media files; existing files kept.")
            except Cancelled:
                raise
            except Exception as e:
                error_sections.append(section)
                with STATE.lock:
                    STATE.section_results[section] = "failed"
                    STATE.fail_count += 1
                message = format_instagram_error(str(e), browser=bool(browser), legacy=bool(legacy))
                last_failure = f"{section}: {message[:650]}"
                STATE.log(f"{section.title()} failed: {message}")
                if any(term in message.lower() for term in ("429", "403", "login", "challenge", "checkpoint", "rate limit", "profile lookup failed", "did not provide profile data")):
                    STATE.log("Instagram denied this session. Stopping additional requests to avoid repeated restrictions.")
                    break
        with STATE.lock:
            STATE.phase = "partial" if error_sections else "completed"
            STATE.error = (("Some sections failed: " + ", ".join(error_sections) +
                           (". " + last_failure if last_failure else ". Connect a browser session to access highlights and stories."))
                           if error_sections else "")
        STATE.log("Done. Downloaded files remain on disk even if some sections failed.")
    except Cancelled as e:
        with STATE.lock:
            STATE.phase, STATE.error = "stopped", str(e)
        STATE.log(str(e))
    except Exception as e:
        with STATE.lock:
            STATE.phase, STATE.error = "failed", str(e)
        STATE.log(f"Stopped: {e}")
    finally:
        with STATE.lock:
            STATE.busy = False
            STATE.section = ""
            STATE.finished_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def zip_worker():
    try:
        with STATE.lock:
            root = STATE.root
        if not root:
            raise ValueError("Download a profile first.")
        export = root.parent / "_zip_exports" / f"{root.name}_archive.zip"
        STATE.log("Building ZIP archive. Large profiles may take a little time...")
        make_archive(root, export)
        with STATE.lock:
            STATE.zip_file = export
        STATE.log(f"ZIP archive ready: {export.name}")
    except Exception as e:
        STATE.log(f"ZIP creation failed: {e}")
        with STATE.lock:
            STATE.error = "ZIP error: " + str(e)
    finally:
        with STATE.lock:
            STATE.zip_busy = False


class Handler(BaseHTTPRequestHandler):
    server_version = "InstagramArchiveStudio/1.5"

    def log_message(self, *args):
        return

    def _headers(self, code=200, mime="application/json; charset=utf-8", length=None):
        self.send_response(code)
        self.send_header("Content-Type", mime)
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        if length is not None:
            self.send_header("Content-Length", str(length))
        self.end_headers()

    def _json(self, data, status=200):
        encoded = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self._headers(status, length=len(encoded))
        self.wfile.write(encoded)

    def _file(self, path, mime, attachment=None):
        try:
            with open(path, "rb") as f:
                size = path.stat().st_size
                self.send_response(200)
                self.send_header("Content-Type", mime)
                self.send_header("Content-Length", str(size))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                if attachment:
                    self.send_header("Content-Disposition", f'attachment; filename="{attachment}"')
                self.end_headers()
                shutil.copyfileobj(f, self.wfile, 512 * 1024)
        except (BrokenPipeError, ConnectionResetError):
            return
        except FileNotFoundError:
            self._json({"error": "File not found"}, 404)

    def _safe_host(self):
        # Deny DNS-rebinding attempts to reach a local authenticated app via a foreign hostname.
        host = (self.headers.get("Host", "") or "").split(":")[0].lower()
        return host in ("127.0.0.1", "localhost")

    def do_GET(self):
        if not self._safe_host():
            self._json({"error": "Only local connections are allowed"}, 403)
            return
        path = urlparse(self.path).path
        if path == "/":
            html = (WEB / "index.html").read_text("utf-8").replace("__APP_KEY__", STATE.key)
            data = html.encode("utf-8")
            self._headers(200, "text/html; charset=utf-8", len(data))
            self.wfile.write(data)
        elif path == "/api/status":
            self._json(STATE.snapshot())
        elif path == "/api/archive.zip":
            with STATE.lock:
                z = STATE.zip_file
            if z and z.is_file():
                self._file(z, "application/zip", z.name)
            else:
                self._json({"error": "Create the ZIP first"}, 404)
        elif path.startswith("/media/"):
            with STATE.lock:
                root = STATE.root
            if not root:
                self._json({"error": "No archive"}, 404)
                return
            # Reject symlinks and directory traversal, even percent-encoded variants.
            rel = unquote(path[len("/media/"):])
            file_path = (root / rel).resolve()
            try:
                file_path.relative_to(root.resolve())
            except ValueError:
                self._json({"error": "Invalid file path"}, 403)
                return
            if not file_path.is_file() or file_path.is_symlink() or file_path.suffix.lower() not in SAFE_FILES:
                self._json({"error": "File not found"}, 404)
                return
            mime = mimetypes.guess_type(file_path.name)[0] or "application/octet-stream"
            self._file(file_path, mime)
        else:
            self._json({"error": "Not found"}, 404)

    def do_POST(self):
        if not self._safe_host():
            self._json({"error": "Only local connections are allowed"}, 403)
            return
        if self.headers.get("X-App-Key") != STATE.key or self.headers.get("Content-Type", "").split(";")[0].lower() != "application/json":
            self._json({"error": "Unauthorized local request"}, 403)
            return
        size = int(self.headers.get("Content-Length", "0") or 0)
        if size > 240 * 1024:
            self._json({"error": "Request too large"}, 413)
            return
        try:
            data = json.loads(self.rfile.read(size) or b"{}")
            if not isinstance(data, dict):
                raise ValueError("Expected a JSON object")
            method = urlparse(self.path).path
            if method in ("/api/login", "/api/cookies", "/api/import-cookies", "/api/2fa", "/api/logout"):
                with STATE.lock:
                    if STATE.busy or STATE.auth_status == "connecting":
                        raise ValueError("Finish the current task first.")
                if method == "/api/logout":
                    with STATE.lock:
                        STATE.account = None
                        STATE.auth_status = "signed_out"
                        STATE.twofa_loader = None
                        STATE.twofa_username = None
                        STATE.auth_error = ""
                    STATE.browser = None
                    for path in (SESSION, ACCOUNT, BROWSER, IMPORTED_COOKIES, SESSIONS / "legacy-gallery.cookies.txt"):
                        path.unlink(missing_ok=True)
                    STATE.log("Signed out and erased locally saved session cookies.")
                elif method == "/api/login":
                    username = normalize_profile(str(data.get("username", "")))
                    password = str(data.get("password", ""))
                    if not password:
                        raise ValueError("Enter an Instagram password.")
                    with STATE.lock:
                        STATE.auth_status = "connecting"
                        STATE.auth_error = ""
                    threading.Thread(target=login_worker, args=(username, password), daemon=True).start()
                elif method == "/api/2fa":
                    code = str(data.get("code", "")).strip()
                    if not re.fullmatch(r"[0-9]{4,10}", code):
                        raise ValueError("Enter the verification code.")
                    with STATE.lock:
                        if STATE.auth_status != "two_factor":
                            raise ValueError("No two-factor challenge is pending.")
                        STATE.auth_status = "connecting"
                    threading.Thread(target=twofa_worker, args=(code,), daemon=True).start()
                elif method == "/api/import-cookies":
                    if importlib.util.find_spec("gallery_dl") is None:
                        raise ValueError("gallery-dl is not installed. Restart start_windows.bat to install it.")
                    import_cookie_export(data.get("contents", ""))
                elif method == "/api/cookies":
                    if importlib.util.find_spec("gallery_dl") is None:
                        raise ValueError("gallery-dl is not installed. Restart start_windows.bat to install it.")
                    browser = str(data.get("browser", "")).lower()
                    if browser not in ("chrome", "edge", "firefox", "brave"):
                        raise ValueError("Choose Chrome, Edge, Firefox or Brave.")
                    with STATE.lock:
                        STATE.auth_status = "connecting"
                        STATE.auth_error = ""
                    threading.Thread(target=cookies_worker, args=(browser,), daemon=True).start()
                self._json({"ok": True})
            elif method == "/api/start":
                normalize_profile(str(data.get("profile", "")))
                folder = str(data.get("folder") or DEFAULT_OUT).strip()
                if not folder or "\x00" in folder:
                    raise ValueError("Select a valid local folder.")
                folder_path = Path(os.path.expandvars(os.path.expanduser(folder)))
                if not folder_path.is_absolute():
                    raise ValueError("Output folder must be a full local path.")
                opts = {"profile": data["profile"], "folder": folder,
                        "posts": bool(data.get("posts")), "reels": bool(data.get("reels")),
                        "highlights": bool(data.get("highlights")), "stories": bool(data.get("stories")),
                        "picture": bool(data.get("picture")), "captions": bool(data.get("captions")),
                        "metadata": bool(data.get("metadata")), "limit": data.get("limit", 0)}
                if not any(opts[k] for k in ("posts", "reels", "highlights", "stories", "picture")):
                    raise ValueError("Choose at least one media type.")
                try:
                    opts["limit"] = int(opts["limit"] or 0)
                except (TypeError, ValueError):
                    raise ValueError("Post/reel limit must be a number.")
                if not 0 <= opts["limit"] <= 10000:
                    raise ValueError("Limit must be between 0 and 10,000 (0 means all).")
                with STATE.lock:
                    if STATE.busy or STATE.zip_busy or STATE.auth_status == "connecting":
                        raise ValueError("Another task is already running.")
                    STATE.busy = True
                    STATE.cancel.clear()
                threading.Thread(target=download_worker, args=(opts,), daemon=True).start()
                self._json({"ok": True})
            elif method == "/api/stop":
                with STATE.lock:
                    if STATE.busy:
                        STATE.cancel.set()
                self._json({"ok": True})
            elif method == "/api/zip":
                with STATE.lock:
                    if STATE.busy or STATE.zip_busy or not STATE.root:
                        raise ValueError("Finish the download first.")
                    STATE.zip_busy = True
                    STATE.zip_file = None
                threading.Thread(target=zip_worker, daemon=True).start()
                self._json({"ok": True})
            elif method == "/api/open-folder":
                with STATE.lock:
                    root = STATE.root
                if not root or not root.is_dir():
                    raise ValueError("No downloaded folder yet.")
                if os.environ.get("IAS_ANDROID_EMBEDDED") == "1":
                    self._json({"ok": True, "folder": str(root), "message": "Files are stored in the app media folder. Tap a recent-media item to export it."})
                    return
                if sys.platform == "win32":
                    os.startfile(str(root))
                elif sys.platform == "darwin":
                    subprocess.Popen(["open", str(root)])
                else:
                    subprocess.Popen(["xdg-open", str(root)])
                self._json({"ok": True})
            else:
                self._json({"error": "Endpoint not found"}, 404)
        except Exception as e:
            self._json({"error": str(e)[:500]}, 400)


def main():
    parser = argparse.ArgumentParser(description="Local Instagram post, reel and highlight archiver")
    parser.add_argument("--no-browser", action="store_true", help="Do not auto-open the browser")
    parser.add_argument("--port", type=int, default=0, help="Local port (0 = automatic)")
    args = parser.parse_args()
    WEB.mkdir(exist_ok=True)
    DATA.mkdir(exist_ok=True)
    DEFAULT_OUT.mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    url = f"http://127.0.0.1:{server.server_port}/"
    print(f"\nInstagram Archive Studio v{APP_VERSION} — gallery-dl {installed_gallery_version()} — running locally", flush=True)
    print("Open:", url, flush=True)
    print("Only localhost can access this app. Press Ctrl+C to stop.\n", flush=True)
    if not args.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
