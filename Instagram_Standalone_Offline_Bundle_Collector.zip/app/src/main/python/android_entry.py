import os
import shutil
import threading
from pathlib import Path

_server = None
_thread = None
_port = 8876
def start(app_files, download_dir, html):
    global _server, _thread
    base = Path(str(app_files)) / 'engine'
    web = base / 'web'
    web.mkdir(parents=True, exist_ok=True)
    (web / 'index.html').write_text(str(html), encoding='utf-8')
    os.environ['IAS_BASE'] = str(base)
    os.environ['IAS_DOWNLOAD_DIR'] = str(download_dir)
    os.environ['IAS_ANDROID_EMBEDDED'] = '1'
    os.environ['HOME'] = str(app_files)
    # import *after* setting env because STATE and BASE are module globals.
    import app
    from http.server import ThreadingHTTPServer
    if _server is not None:
        return _port
    Path(str(download_dir)).mkdir(parents=True, exist_ok=True)
    _server = ThreadingHTTPServer(('127.0.0.1', _port), app.Handler)
    _thread = threading.Thread(target=_server.serve_forever, daemon=True)
    _thread.start()
    return _port
def stop():
    global _server
    if _server:
        _server.shutdown()
        _server.server_close()
        _server = None
